iptables -t filter -vnL INPUT
