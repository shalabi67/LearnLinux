iptables -t nat -vnL
