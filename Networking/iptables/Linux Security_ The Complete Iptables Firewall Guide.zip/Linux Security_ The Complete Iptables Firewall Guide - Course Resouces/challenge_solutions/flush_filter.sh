iptables -F
#or
iptables -t filter -F
