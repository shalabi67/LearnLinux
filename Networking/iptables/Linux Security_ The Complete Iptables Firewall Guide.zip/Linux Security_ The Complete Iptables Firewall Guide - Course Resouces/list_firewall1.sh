#!/bin/bash

iptables-save
