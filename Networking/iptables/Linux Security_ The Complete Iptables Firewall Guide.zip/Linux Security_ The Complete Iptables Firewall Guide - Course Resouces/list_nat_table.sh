#!/bin/bash

iptables -t nat -vnL
