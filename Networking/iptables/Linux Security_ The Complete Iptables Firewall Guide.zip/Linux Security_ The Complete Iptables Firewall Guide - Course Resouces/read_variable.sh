#!/bin/bash

echo -n "Enter something:"
read MYVARIABLE
echo "You entered $MYVARIABLE"
